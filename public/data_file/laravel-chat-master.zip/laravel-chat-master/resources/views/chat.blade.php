@extends('layouts.app')
@section('content')
<example></example>
@endsection